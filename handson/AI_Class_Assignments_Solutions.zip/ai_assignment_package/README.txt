PYTHON/AI CLASS ASSIGNMENT PACKAGE

Two classroom assignments are included:

1. AI APIs, Copilots & Enterprise Productivity
   - AI-powered enterprise support assistant
   - Includes assignment document and complete solution code.

2. AI-Assisted Development & Cloud Engineering Workflows
   - Cloud deployment readiness analyzer
   - Includes assignment document, sample project and complete solution code.

Suggested teaching method:
- Give students only the assignment document first.
- Keep the *_solution.py files for instructor/reference use.
- Students should implement the solution independently before reviewing the supplied code.

No external Python packages are required.
