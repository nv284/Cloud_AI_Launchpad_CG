import json
from datetime import datetime
from pathlib import Path

DATA_FILE = Path("support_requests.json")

CATEGORIES = {
    "Access": {"access", "permission", "login", "account"},
    "Software": {"install", "software", "application", "app", "ide"},
    "Network": {"vpn", "network", "internet", "wifi", "connection"},
    "Password": {"password", "reset", "credential"},
    "Development": {"code", "github", "build", "api", "deployment"},
}

ACTIONS = {
    "Access": [
        "Verify employee identity",
        "Check access request status",
        "Contact IT if access is still unavailable",
    ],
    "Software": [
        "Confirm software name and version",
        "Check installation permission",
        "Use only approved enterprise software",
    ],
    "Network": [
        "Check network connection",
        "Reconnect VPN if required",
        "Contact network support if the issue continues",
    ],
    "Password": [
        "Use the approved password-reset process",
        "Verify identity",
        "Escalate suspicious activity to IT security",
    ],
    "Development": [
        "Collect project and error details",
        "Check logs",
        "Escalate to development support if required",
    ],
    "Other": [
        "Collect additional details",
        "Check the internal knowledge base",
        "Escalate to the appropriate support team",
    ],
}

def categorize_request(question):
    words = set(
        question.lower()
        .replace("/", " ")
        .replace("-", " ")
        .split()
    )

    for category, keywords in CATEGORIES.items():
        if words & keywords:
            return category

    return "Other"

def build_ai_prompt(name, department, question, priority, category):
    return f"""You are an enterprise IT support AI assistant.

Employee: {name}
Department: {department}
Priority: {priority}
Category: {category}

Employee request:
{question}

Instructions:
1. Understand the issue.
2. Give a concise and practical response.
3. Ask for missing information when required.
4. Never invent company policies or permissions.
5. Escalate security-sensitive issues to IT/security support.
6. Use a professional enterprise communication style.
"""

def call_ai_api(prompt, category):
    # Simulated API response for classroom use.
    return (
        f"AI Assistant Response ({category}): "
        "Please follow the approved enterprise support process, "
        "verify the relevant details, and contact the appropriate "
        "support team if the issue cannot be resolved."
    )

def save_request(record):
    records = []

    if DATA_FILE.exists():
        try:
            records = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            records = []

    records.append(record)
    DATA_FILE.write_text(
        json.dumps(records, indent=2),
        encoding="utf-8"
    )

def show_action_checklist(category):
    print("\nCOPILOT-STYLE ACTION CHECKLIST")
    for number, action in enumerate(
        ACTIONS.get(category, ACTIONS["Other"]), 1
    ):
        print(f"{number}. {action}")

def show_productivity_summary():
    if not DATA_FILE.exists():
        return

    try:
        records = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        print("Unable to read request history.")
        return

    print("\nPRODUCTIVITY SUMMARY")
    print("-" * 40)
    print(f"Total requests: {len(records)}")
    print(
        "High priority:",
        sum(r["priority"] == "High" for r in records)
    )

    category_counts = {}
    for record in records:
        category = record["category"]
        category_counts[category] = category_counts.get(category, 0) + 1

    for category, count in category_counts.items():
        print(f"{category}: {count}")

def main():
    print("AI-POWERED ENTERPRISE SUPPORT ASSISTANT")
    print("=" * 50)

    name = input("Employee name: ").strip()
    department = input("Department: ").strip()
    question = input("Support question: ").strip()
    priority = input("Priority (Low/Medium/High): ").strip().title()

    if not name or not department or not question:
        print("Employee name, department and question are required.")
        return

    if priority not in {"Low", "Medium", "High"}:
        print("Priority must be Low, Medium or High.")
        return

    category = categorize_request(question)
    prompt = build_ai_prompt(
        name, department, question, priority, category
    )
    response = call_ai_api(prompt, category)

    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "employee": name,
        "department": department,
        "question": question,
        "priority": priority,
        "category": category,
        "ai_prompt": prompt,
        "ai_response": response,
    }

    save_request(record)

    print("\nCategory:", category)
    print("\nAI RESPONSE:")
    print(response)

    show_action_checklist(category)
    show_productivity_summary()

if __name__ == "__main__":
    main()
