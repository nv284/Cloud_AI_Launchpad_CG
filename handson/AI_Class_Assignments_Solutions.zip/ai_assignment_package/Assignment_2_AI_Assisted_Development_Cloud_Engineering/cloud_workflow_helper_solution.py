import json
from datetime import datetime
from pathlib import Path

REQUIRED_FILES = [
    "app.py",
    "requirements.txt",
    ".env.example",
    "Dockerfile",
    "README.md",
]

POINTS = {
    "app.py": 20,
    "requirements.txt": 20,
    ".env.example": 20,
    "Dockerfile": 20,
    "README.md": 20,
}

def inspect_project(project_path):
    path = Path(project_path)

    if not path.exists() or not path.is_dir():
        raise ValueError(
            "Project path does not exist or is not a directory."
        )

    return {
        filename: (path / filename).exists()
        for filename in REQUIRED_FILES
    }

def calculate_readiness(checks):
    return sum(
        POINTS[filename]
        for filename, exists in checks.items()
        if exists
    )

def generate_development_report(checks):
    report = []

    for filename, exists in checks.items():
        status = "PASS" if exists else "NOT FOUND"
        report.append(f"{filename}: {status}")

    return report

def generate_deployment_commands(checks):
    commands = [
        "python -m venv .venv",
        "pip install -r requirements.txt",
        "python app.py",
    ]

    if checks["Dockerfile"]:
        commands.extend([
            "docker build -t sample-app .",
            "docker run -p 8000:8000 sample-app",
        ])

    return commands

def build_ai_review_prompt(checks):
    file_status = "\n".join(
        f"- {filename}: {'present' if exists else 'missing'}"
        for filename, exists in checks.items()
    )

    return f"""You are an AI coding and cloud engineering assistant.

Review the following project readiness information:

{file_status}

Provide:
1. Code-quality observations.
2. Missing cloud-readiness items.
3. Configuration-management recommendations.
4. Docker/container recommendations.
5. Logging and error-handling recommendations.
6. Security considerations.
7. A practical deployment checklist.

Important:
- Do not invent project requirements.
- Clearly distinguish observations from recommendations.
- Do not expose or request real secrets.
- Do not claim that deployment has been performed.
"""

def save_report(report, filename="cloud_workflow_report.json"):
    Path(filename).write_text(
        json.dumps(report, indent=2),
        encoding="utf-8"
    )

def main():
    print("AI-ASSISTED CLOUD DEPLOYMENT READINESS ANALYZER")
    print("=" * 60)

    project_path = input(
        "Enter sample project directory path: "
    ).strip()

    try:
        checks = inspect_project(project_path)
    except ValueError as error:
        print("Error:", error)
        return

    score = calculate_readiness(checks)
    development_report = generate_development_report(checks)
    commands = generate_deployment_commands(checks)
    ai_prompt = build_ai_review_prompt(checks)

    report = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "project_path": str(Path(project_path).resolve()),
        "file_checks": checks,
        "cloud_readiness_score": score,
        "development_report": development_report,
        "deployment_commands": commands,
        "ai_review_prompt": ai_prompt,
    }

    save_report(report)

    print("\nFILE CHECKS")
    print("-" * 40)
    for line in development_report:
        print(line)

    print(f"\nCloud Readiness: {score}/100")

    print("\nDEPLOYMENT COMMANDS")
    print("-" * 40)
    for command in commands:
        print(command)

    print("\nAI REVIEW PROMPT")
    print("-" * 40)
    print(ai_prompt)

    print("\nReport saved to cloud_workflow_report.json")

if __name__ == "__main__":
    main()
