print("Sample cloud-ready application")
