# Sample App

Small Python application for the class assignment.
