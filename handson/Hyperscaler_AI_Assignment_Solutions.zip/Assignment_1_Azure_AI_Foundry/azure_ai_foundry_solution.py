import json
from datetime import datetime
from pathlib import Path

HISTORY_FILE = Path("azure_ai_interactions.json")

KNOWLEDGE_BASE = {
    "leave": "Employees can apply for leave through the approved HR portal.",
    "password": "Employees must use the approved password-reset process.",
    "travel": "Eligible business travel expenses must be submitted through the approved expense process.",
    "work from home": "Employees should follow their organization's approved remote-work process.",
    "training": "Employees can request approved learning programs through the training process."
}

def search_knowledge_base(question):
    q = question.lower()
    matches = []

    for topic, content in KNOWLEDGE_BASE.items():
        if topic in q:
            matches.append({"topic": topic, "content": content})

    return matches

def build_grounded_prompt(question, context):
    context_text = "\n".join(item["content"] for item in context)

    return f"""You are an enterprise policy assistant.

Question:
{question}

Trusted context:
{context_text}

Rules:
1. Use only the trusted context.
2. Do not invent company policies.
3. If the context is insufficient, clearly say so.
4. Give a concise, business-friendly answer.
"""

def generate_response(question, context):
    if not context:
        return (
            "The available knowledge base does not contain enough "
            "information to answer this question."
        )

    return context[0]["content"]

def save_interaction(record):
    records = []

    if HISTORY_FILE.exists():
        try:
            records = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            records = []

    records.append(record)
    HISTORY_FILE.write_text(
        json.dumps(records, indent=2),
        encoding="utf-8"
    )

def main():
    print("AZURE AI FOUNDRY - DOCUMENT INTELLIGENCE ASSISTANT")
    print("=" * 60)

    question = input("Ask a policy question: ").strip()

    if not question:
        print("Question cannot be empty.")
        return

    context = search_knowledge_base(question)
    prompt = build_grounded_prompt(question, context)
    response = generate_response(question, context)

    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "question": question,
        "retrieved_context": context,
        "prompt": prompt,
        "response": response
    }

    save_interaction(record)

    print("\nRETRIEVED CONTEXT")
    print(context)

    print("\nGROUNDED PROMPT")
    print(prompt)

    print("\nRESPONSE")
    print(response)

if __name__ == "__main__":
    main()
