HYPERSCALER AI CLASS ASSIGNMENTS

Assignment 1:
Azure AI Foundry - Enterprise Document Intelligence Assistant

Assignment 2:
AWS Bedrock + Google Cloud Vertex AI - Multi-Cloud AI Model Gateway

Word documents are student-facing assignments.
Python files are instructor/reference solutions.

The solutions use MOCK mode by default so students can learn the architecture without
incurring cloud charges. Real cloud integration should only be enabled with instructor
authorization and approved credentials.

Never hard-code or commit cloud credentials.
