import json
import os
import time
from datetime import datetime
from pathlib import Path

HISTORY_FILE = Path("ai_gateway_history.json")
SUPPORTED_PROVIDERS = {"mock", "aws", "gcp"}

def invoke_mock(prompt):
    return {
        "status": "success",
        "response": (
            "Mock AI response: "
            f"The request was received successfully. Prompt length: {len(prompt)} characters."
        )
    }

def invoke_aws_bedrock(prompt):
    region = os.getenv("AWS_REGION")

    if not region:
        return {
            "status": "configuration_required",
            "response": (
                "AWS Bedrock is not configured. Set AWS_REGION and configure "
                "approved AWS credentials before making a real model call."
            )
        }

    # Instructor extension point:
    # Add the approved AWS Bedrock SDK/model invocation here.
    return {
        "status": "integration_ready",
        "response": (
            "AWS Bedrock adapter is configured for region "
            f"{region}, but the classroom solution does not invoke a paid model."
        )
    }

def invoke_vertex_ai(prompt):
    project = os.getenv("GOOGLE_CLOUD_PROJECT")
    location = os.getenv("GOOGLE_CLOUD_LOCATION")

    if not project or not location:
        return {
            "status": "configuration_required",
            "response": (
                "Vertex AI is not configured. Set GOOGLE_CLOUD_PROJECT and "
                "GOOGLE_CLOUD_LOCATION and configure approved GCP credentials."
            )
        }

    # Instructor extension point:
    # Add the approved Vertex AI SDK/model invocation here.
    return {
        "status": "integration_ready",
        "response": (
            f"Vertex AI adapter is configured for project {project} "
            f"in {location}, but the classroom solution does not invoke a paid model."
        )
    }

def invoke_model(provider, prompt):
    provider = provider.strip().lower()

    if provider not in SUPPORTED_PROVIDERS:
        raise ValueError(
            "Unsupported provider. Choose Mock, AWS or GCP."
        )

    if not prompt.strip():
        raise ValueError("Prompt cannot be empty.")

    if provider == "mock":
        result = invoke_mock(prompt)
    elif provider == "aws":
        result = invoke_aws_bedrock(prompt)
    else:
        result = invoke_vertex_ai(prompt)

    return {
        "provider": provider,
        "status": result["status"],
        "response": result["response"]
    }

def save_history(record):
    records = []

    if HISTORY_FILE.exists():
        try:
            records = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            records = []

    records.append(record)

    HISTORY_FILE.write_text(
        json.dumps(records, indent=2),
        encoding="utf-8"
    )

def main():
    print("MULTI-CLOUD AI MODEL GATEWAY")
    print("=" * 50)

    provider = input("Provider (Mock/AWS/GCP): ").strip()
    prompt = input("Prompt: ").strip()

    start = time.perf_counter()

    try:
        result = invoke_model(provider, prompt)
    except ValueError as error:
        print("Validation error:", error)
        return
    except Exception as error:
        print("Unexpected error:", error)
        return

    latency_ms = round((time.perf_counter() - start) * 1000, 2)

    record = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "provider": result["provider"],
        "prompt": prompt,
        "status": result["status"],
        "response": result["response"],
        "latency_ms": latency_ms
    }

    save_history(record)

    print("\nPROVIDER:", result["provider"])
    print("STATUS:", result["status"])
    print("LATENCY:", latency_ms, "ms")
    print("RESPONSE:", result["response"])

if __name__ == "__main__":
    main()
