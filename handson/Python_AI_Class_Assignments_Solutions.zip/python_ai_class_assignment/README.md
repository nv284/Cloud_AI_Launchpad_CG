# Python Foundations for AI — Class Assignments

This package contains 3 hands-on assignments covering:
1. Python Foundations for AI
2. Python for AI Integration & Automation
3. AI-ready data processing and automation

Each assignment folder contains:
- PROBLEM_STATEMENT.md
- INSTRUCTIONS.md
- Solution Python code

Suggested classroom flow:
- Students first receive only the problem statement and instructions.
- Ask students to implement their own solution.
- Use the supplied solution code only for review/discussion after submission.

Requirements:
- Python 3.10+
- No external packages are required.
