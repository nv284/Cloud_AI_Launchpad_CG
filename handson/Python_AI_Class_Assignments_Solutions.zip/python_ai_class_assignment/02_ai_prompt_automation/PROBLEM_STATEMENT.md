Build a Python automation utility that prepares prompts for an AI assistant.

Scenario:
A company receives many customer-support questions. Before sending a question to an AI system, employees must convert the raw customer message into a consistent prompt containing the customer issue, priority, desired response style, and output format.

Learning objectives:
- Python functions and string manipulation
- Dictionaries and JSON
- File handling
- Input validation
- Automation-oriented program design
- Preparing data for an AI API without requiring a real API key