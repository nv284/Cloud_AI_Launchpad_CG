import json
from datetime import datetime
from pathlib import Path

REQUEST_FILE = Path("requests.json")
VALID_PRIORITIES = {"Low", "Medium", "High"}

def build_prompt(name, message, priority, style):
    return f"""You are a customer-support AI assistant.

Customer: {name}
Priority: {priority}
Preferred response style: {style}

Customer message:
{message}

Instructions:
1. Understand the customer's issue.
2. Provide a concise and practical solution.
3. Clearly mention any information that is missing.
4. Do not invent policies, prices, technical facts, or account details.
5. If the issue needs human support, state the next recommended action.
"""

def save_request(data):
    existing = []

    if REQUEST_FILE.exists():
        try:
            existing = json.loads(REQUEST_FILE.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            existing = []

    existing.append(data)
    REQUEST_FILE.write_text(
        json.dumps(existing, indent=2),
        encoding="utf-8"
    )

def show_history():
    if not REQUEST_FILE.exists():
        print("No previous requests found.")
        return

    requests = json.loads(REQUEST_FILE.read_text(encoding="utf-8"))
    print("\nPREVIOUS REQUESTS")
    print("-" * 60)

    for item in requests:
        print(f"{item['timestamp']} | {item['name']} | {item['priority']}")
        print(item["prompt"])
        print("-" * 60)

def main():
    print("AI Prompt Automation Assistant")

    name = input("Customer name: ").strip()
    message = input("Customer message: ").strip()
    priority = input("Priority (Low/Medium/High): ").strip().title()
    style = input("Response style (professional/friendly/concise): ").strip()

    if not name or not message:
        print("Name and message are required.")
        return

    if priority not in VALID_PRIORITIES:
        print("Invalid priority. Use Low, Medium or High.")
        return

    prompt = build_prompt(name, message, priority, style)

    request = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "name": name,
        "priority": priority,
        "style": style,
        "prompt": prompt
    }

    save_request(request)

    print("\nGENERATED AI PROMPT")
    print("=" * 60)
    print(prompt)
    print("\nRequest saved to requests.json.")

if __name__ == "__main__":
    main()
