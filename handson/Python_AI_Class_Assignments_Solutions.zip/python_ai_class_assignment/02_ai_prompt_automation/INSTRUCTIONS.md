1. Create a Python program named ai_prompt_automation.py.
2. Accept customer name, customer message, priority and preferred response style.
3. Validate priority as Low, Medium or High.
4. Build a structured prompt using a reusable function.
5. Include instructions asking an AI assistant to:
   - understand the issue,
   - provide a concise solution,
   - mention missing information,
   - avoid inventing facts.
6. Save every generated request into requests.json.
7. Add a timestamp to each saved request.
8. Display the generated prompt on the console.
9. Add a function that loads and displays previous requests.
10. Do not call a real AI API; the assignment focuses on Python automation and AI integration preparation.
11. Extension: create a batch mode that reads multiple customer requests from input.json.