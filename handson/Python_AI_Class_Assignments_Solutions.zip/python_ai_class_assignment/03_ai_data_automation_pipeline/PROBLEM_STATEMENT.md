Build a Python automation pipeline that processes a collection of customer feedback messages and prepares AI-ready input.

Scenario:
A company collects customer feedback in a text file. The operations team wants an automated Python utility that cleans the data, detects basic sentiment using keyword rules, categorizes each message, and creates structured AI prompts for further analysis.

Learning objectives:
- File handling
- String processing
- Lists and dictionaries
- Functions
- Simple rule-based automation
- JSON generation
- AI integration preparation