1. Create a Python program named feedback_automation.py.
2. Create/read a file named feedback.txt containing one customer feedback message per line.
3. Ignore blank lines.
4. Clean extra spaces and normalize text.
5. Detect basic sentiment using configurable positive and negative keyword lists.
6. Categorize feedback into at least:
   - Product
   - Service
   - Delivery
   - Other
7. Create a structured dictionary for every feedback item containing:
   id, original_text, cleaned_text, category, sentiment.
8. Generate an AI-analysis prompt for each item.
9. Save the structured results to feedback_analysis.json.
10. Save all AI prompts to ai_prompts.txt.
11. Display a summary showing total feedback, category counts and sentiment counts.
12. Use functions; do not use pandas.
13. Extension: add a command-line option or menu to process the file again.