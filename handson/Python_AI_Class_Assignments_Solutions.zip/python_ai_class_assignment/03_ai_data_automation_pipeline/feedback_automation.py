import json
from collections import Counter
from pathlib import Path

FEEDBACK_FILE = Path("feedback.txt")
RESULT_FILE = Path("feedback_analysis.json")
PROMPT_FILE = Path("ai_prompts.txt")

POSITIVE_WORDS = {"good", "great", "excellent", "happy", "fast", "helpful", "love"}
NEGATIVE_WORDS = {"bad", "poor", "slow", "late", "unhappy", "broken", "hate"}

CATEGORY_KEYWORDS = {
    "Product": {"product", "feature", "quality", "broken", "app", "software"},
    "Service": {"support", "service", "agent", "helpful", "response"},
    "Delivery": {"delivery", "deliver", "shipping", "package", "late"},
}

def clean_text(text):
    return " ".join(text.strip().split())

def detect_sentiment(text):
    words = set(text.lower().replace(".", "").replace(",", "").split())
    positive = len(words & POSITIVE_WORDS)
    negative = len(words & NEGATIVE_WORDS)

    if positive > negative:
        return "Positive"
    if negative > positive:
        return "Negative"
    return "Neutral"

def detect_category(text):
    words = set(text.lower().replace(".", "").replace(",", "").split())

    for category, keywords in CATEGORY_KEYWORDS.items():
        if words & keywords:
            return category

    return "Other"

def build_ai_prompt(item):
    return f"""Analyze this customer feedback.

Feedback ID: {item['id']}
Category: {item['category']}
Rule-based sentiment: {item['sentiment']}

Text:
{item['cleaned_text']}

Return:
1. A one-sentence summary.
2. The main customer issue.
3. A suggested business action.
4. A confidence level (Low/Medium/High).

Do not invent information that is not present in the feedback.
"""

def process_feedback():
    if not FEEDBACK_FILE.exists():
        FEEDBACK_FILE.write_text(
            "Great product and very fast delivery.\n"
            "The support service was slow and unhelpful.\n"
            "My package arrived late.\n"
            "The new app feature is excellent.\n"
            "I have a question about my account.\n",
            encoding="utf-8"
        )
        print("Sample feedback.txt created.")

    lines = FEEDBACK_FILE.read_text(encoding="utf-8").splitlines()
    cleaned_lines = [clean_text(line) for line in lines if clean_text(line)]

    results = []
    prompts = []

    for index, text in enumerate(cleaned_lines, start=1):
        item = {
            "id": index,
            "original_text": text,
            "cleaned_text": text,
            "category": detect_category(text),
            "sentiment": detect_sentiment(text),
        }
        results.append(item)
        prompts.append(build_ai_prompt(item))

    RESULT_FILE.write_text(
        json.dumps(results, indent=2),
        encoding="utf-8"
    )
    PROMPT_FILE.write_text(
        "\n" + "\n" + ("-" * 70 + "\n").join(prompts),
        encoding="utf-8"
    )

    category_counts = Counter(item["category"] for item in results)
    sentiment_counts = Counter(item["sentiment"] for item in results)

    print("\nFEEDBACK AUTOMATION SUMMARY")
    print("-" * 40)
    print(f"Total feedback: {len(results)}")

    print("\nCategories:")
    for category, count in category_counts.items():
        print(f"  {category}: {count}")

    print("\nSentiment:")
    for sentiment, count in sentiment_counts.items():
        print(f"  {sentiment}: {count}")

    print("\nGenerated:")
    print(f"  {RESULT_FILE}")
    print(f"  {PROMPT_FILE}")

if __name__ == "__main__":
    process_feedback()
