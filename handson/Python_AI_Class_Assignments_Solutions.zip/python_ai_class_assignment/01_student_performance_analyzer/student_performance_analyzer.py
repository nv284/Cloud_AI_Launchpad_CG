students = [
    {"name": "Aarav", "Python": 82, "AI": 78, "Math": 91},
    {"name": "Diya", "Python": 68, "AI": 74, "Math": 63},
    {"name": "Rohan", "Python": 45, "AI": 52, "Math": 48},
    {"name": "Meera", "Python": 92, "AI": 88, "Math": 95},
    {"name": "Kabir", "Python": 35, "AI": 42, "Math": 38},
]

def calculate_grade(percentage):
    if percentage >= 80:
        return "A"
    elif percentage >= 60:
        return "B"
    elif percentage >= 50:
        return "C"
    elif percentage >= 40:
        return "D"
    return "F"

def analyze_student(student):
    subjects = ["Python", "AI", "Math"]
    marks = [student[s] for s in subjects]

    if any(mark < 0 or mark > 100 for mark in marks):
        raise ValueError(f"Invalid marks for {student['name']}")

    total = sum(marks)
    percentage = total / len(marks)
    passed = all(mark >= 40 for mark in marks)

    return {
        "name": student["name"],
        "total": total,
        "percentage": percentage,
        "grade": calculate_grade(percentage),
        "status": "PASS" if passed else "FAIL"
    }

results = [analyze_student(student) for student in students]

print("\nSTUDENT PERFORMANCE REPORT")
print("-" * 65)
for result in results:
    print(
        f"{result['name']:<10} "
        f"Total: {result['total']:<3} "
        f"Percentage: {result['percentage']:.2f}%  "
        f"Grade: {result['grade']}  "
        f"Status: {result['status']}"
    )

class_average = sum(r["percentage"] for r in results) / len(results)
top_student = max(results, key=lambda r: r["percentage"])

print("-" * 65)
print(f"Class Average: {class_average:.2f}%")
print(f"Top Performer: {top_student['name']} ({top_student['percentage']:.2f}%)")
