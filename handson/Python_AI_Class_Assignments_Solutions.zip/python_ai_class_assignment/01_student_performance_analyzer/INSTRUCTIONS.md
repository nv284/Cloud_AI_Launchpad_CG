1. Create a Python program named student_performance_analyzer.py.
2. Store at least 5 students and 3 subjects per student.
3. Calculate each student's total and percentage.
4. Assign grades:
   A: 80% and above
   B: 60–79%
   C: 50–59%
   D: 40–49%
   F: below 40%
5. Mark a student as PASS only if every subject mark is at least 40.
6. Display a formatted report for every student.
7. Calculate and display the class average percentage.
8. Display the name and percentage of the top-performing student.
9. Use at least two user-defined functions.
10. Add basic validation so marks outside 0–100 are rejected.
11. Do not use pandas or other external libraries.
12. Extension: allow the user to search for a student by name.