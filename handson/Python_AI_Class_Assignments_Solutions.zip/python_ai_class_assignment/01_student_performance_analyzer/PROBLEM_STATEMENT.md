Build a Python program that analyzes student marks and generates a simple performance report.

Scenario:
A training institute wants to automatically analyze marks of students across multiple subjects. The program should calculate totals, percentages, grades, pass/fail status, class average, and identify the top performer.

Learning objectives:
- Python variables, data types, input/output
- Lists, dictionaries, loops and conditional statements
- Functions
- Basic exception handling
- Reading structured data from a Python list/dictionary