CATALOG={
"Python AI Foundations":{"duration":2,"level":"Beginner"},
"LangChain Fundamentals":{"duration":2,"level":"Intermediate"},
"Agentic AI":{"duration":3,"level":"Intermediate"},
"Cloud AI Engineering":{"duration":3,"level":"Advanced"}
}

def search_course(course_name):
    for name,details in CATALOG.items():
        if name.lower()==course_name.lower():
            return {"found":True,"course":name,**details}
    return {"found":False,"course":course_name,"message":"Course not found."}

def list_courses_by_level(level):
    return [{"course":n,**d} for n,d in CATALOG.items() if d["level"].lower()==level.lower()]

def calculate_total_days(days1,days2):
    return {"days1":days1,"days2":days2,"total_days":days1+days2}

def find_courses(question):
    return [n for n in CATALOG if n.lower() in question.lower()]

def langchain_style_agent(question):
    q=question.lower()
    if "total" in q and "duration" in q:
        courses=find_courses(question)
        if len(courses)>=2:
            a=search_course(courses[0]); b=search_course(courses[1])
            total=calculate_total_days(a["duration"],b["duration"])
            return {"tools":["search_course","search_course","calculate_total_days"],
                    "observation":{"first":a,"second":b,"calculation":total},
                    "answer":f"Total duration is {total['total_days']} days."}
    if "beginner" in q:
        result=list_courses_by_level("Beginner")
        return {"tools":["list_courses_by_level"],"observation":result,
                "answer":"Beginner courses: "+", ".join(x["course"] for x in result)}
    courses=find_courses(question)
    if courses:
        result=search_course(courses[0])
        return {"tools":["search_course"],"observation":result,
                "answer":f"{result['course']} is {result['level']} and lasts {result['duration']} days."}
    return {"tools":[],"observation":{"found":False},
            "answer":"That course was not found in the training catalog."}

def main():
    q=input("Training question: ").strip()
    result=langchain_style_agent(q)
    print("\nTOOLS:",result["tools"])
    print("OBSERVATION:",result["observation"])
    print("ANSWER:",result["answer"])

if __name__=="__main__": main()

# Optional OpenAI Agents SDK pattern:
#
# from agents import Agent, Runner, function_tool
#
# @function_tool
# def search_course_tool(course_name: str) -> dict:
#     return search_course(course_name)
#
# @function_tool
# def list_courses_by_level_tool(level: str) -> list:
#     return list_courses_by_level(level)
#
# @function_tool
# def calculate_total_days_tool(days1: int, days2: int) -> dict:
#     return calculate_total_days(days1, days2)
#
# agent=Agent(
#   name="Corporate Training Assistant",
#   instructions="Use catalog tools. Never invent course details.",
#   tools=[search_course_tool,list_courses_by_level_tool,calculate_total_days_tool]
# )
# result=Runner.run_sync(agent,"What is the duration of LangChain Fundamentals?")
# print(result.final_output)
