import random

MAX_STEPS = 5

def check_system_status(service):
    status = {"vpn": "Operational", "email": "Operational", "github": "Operational"}
    return {"tool": "check_system_status", "service": service, "status": status.get(service.lower(), "Unknown")}

def check_user_access(user, resource):
    access = {"github": False, "vpn": True, "email": True}
    return {"tool": "check_user_access", "user": user, "resource": resource,
            "access": access.get(resource.lower(), False)}

def create_support_ticket(user, issue):
    return {"tool": "create_support_ticket", "ticket_id": f"INC-{random.randint(1000,9999)}",
            "user": user, "issue": issue, "status": "Created"}

def search_knowledge_base(question):
    q = question.lower()
    if "password" in q:
        answer = "Use the approved password-reset process and verify your identity."
    elif "vpn" in q:
        answer = "Check your network and reconnect using the approved VPN client."
    elif "github" in q:
        answer = "Verify repository permissions with the project administrator."
    else:
        answer = "No matching knowledge-base article was found."
    return {"tool": "search_knowledge_base", "answer": answer}

def decide_action(request):
    q=request.lower()
    if "vpn" in q and any(x in q for x in ["working","status","down","available"]): return "system_status"
    if any(x in q for x in ["access","permission","repository","github"]): return "access_check"
    if any(x in q for x in ["password","reset","how do i"]): return "knowledge_base"
    return "clarification"

def run_agent(user, request):
    state={"user":user,"request":request,"selected_action":None,"tool_input":None,
           "observation":None,"final_response":None,"history":[]}
    for step in range(1,MAX_STEPS+1):
        action=decide_action(request); state["selected_action"]=action
        if action=="system_status":
            result=check_system_status("vpn")
            state["observation"]=result; state["history"].append((step,action,result))
            state["final_response"]=f"VPN status: {result['status']}."; break
        if action=="access_check":
            result=check_user_access(user,"github")
            state["history"].append((step,action,result))
            if result["access"]:
                state["final_response"]="You currently have GitHub access."
            else:
                ticket=create_support_ticket(user,request)
                state["observation"]=ticket
                state["history"].append((step+1,"create_support_ticket",ticket))
                state["final_response"]=f"Access is unavailable. Ticket {ticket['ticket_id']} was created."
            break
        if action=="knowledge_base":
            result=search_knowledge_base(request)
            state["observation"]=result; state["history"].append((step,action,result))
            state["final_response"]=result["answer"]; break
        state["history"].append((step,"clarification",{}))
        state["final_response"]="Please provide more details about the system and issue."
        break
    return state

def main():
    user=input("Employee name: ").strip()
    request=input("Employee request: ").strip()
    if not user or not request: print("Both fields are required."); return
    state=run_agent(user,request)
    print("\nAGENT TRACE")
    for step,action,result in state["history"]:
        print(f"Step {step}: {action} -> {result}")
    print("\nFINAL:",state["final_response"])

if __name__=="__main__": main()
