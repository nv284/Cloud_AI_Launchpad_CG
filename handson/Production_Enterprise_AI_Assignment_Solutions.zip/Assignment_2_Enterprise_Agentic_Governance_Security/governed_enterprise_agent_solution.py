"""
Governed Enterprise Agent - Reference Solution
Standard-library implementation for classroom use.
"""

import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

AUDIT_FILE=Path("audit_log.json")
MAX_STEPS=5

POLICY={
    "meals":"Eligible meal expenses must follow the organization's approved travel policy.",
    "mileage":"Mileage reimbursement uses the organization's approved mileage rate.",
    "receipts":"Expenses above the organization's defined threshold require supporting documentation."
}

ROLES={
    "EMPLOYEE":{"search_expense_policy","calculate_reimbursement"},
    "MANAGER":{"search_expense_policy","calculate_reimbursement","create_human_review_case"},
    "AUDITOR":{"search_expense_policy","calculate_reimbursement","create_human_review_case"}
}

DANGEROUS_PHRASES=[
    "ignore previous instructions",
    "bypass policy",
    "disable security",
    "reveal system prompt",
    "give me the secret"
]

def audit(user_id,role,action,tool,status,details=""):
    event={
        "timestamp":datetime.now(timezone.utc).isoformat(),
        "request_id":str(uuid.uuid4()),
        "user_id":user_id,
        "role":role,
        "action":action,
        "tool":tool,
        "status":status,
        "details":details
    }
    events=[]
    if AUDIT_FILE.exists():
        try: events=json.loads(AUDIT_FILE.read_text())
        except json.JSONDecodeError: events=[]
    events.append(event)
    AUDIT_FILE.write_text(json.dumps(events,indent=2))

def safety_check(text):
    lower=text.lower()
    return [p for p in DANGEROUS_PHRASES if p in lower]

def authorized(role,tool):
    return tool in ROLES.get(role.upper(),set())

def search_expense_policy(topic):
    topic=topic.lower()
    matches={k:v for k,v in POLICY.items() if k in topic}
    return matches

def calculate_reimbursement(amount,rate):
    return round(float(amount)*float(rate),2)

def create_human_review_case(user,reason):
    return {
        "case_id":"HR-"+str(uuid.uuid4())[:8].upper(),
        "user":user,
        "reason":reason,
        "status":"Created"
    }

def run_agent(user_id,role,request):
    role=role.upper()
    suspicious=safety_check(request)

    if suspicious:
        audit(user_id,role,"safety_refusal","none","blocked",
              "Suspicious instruction detected")
        return "I cannot bypass security or reveal protected instructions. Please use the approved process."

    lower=request.lower()

    if "reveal" in lower and "prompt" in lower:
        audit(user_id,role,"protected_information","none","blocked")
        return "I cannot reveal protected system instructions."

    if "approve" in lower or "bypass" in lower:
        if not authorized(role,"create_human_review_case"):
            audit(user_id,role,"create_review","create_human_review_case","denied")
            return "You are not authorized to create this review case directly. Please contact an authorized reviewer."
        case=create_human_review_case(user_id,request)
        audit(user_id,role,"create_review","create_human_review_case","success")
        return f"Human review case {case['case_id']} was created."

    if "calculate" in lower and "rate" in lower:
        numbers=[float(x) for x in re.findall(r"\d+(?:\.\d+)?",request)]
        if len(numbers)>=2:
            if not authorized(role,"calculate_reimbursement"):
                audit(user_id,role,"calculate","calculate_reimbursement","denied")
                return "Your role is not authorized for this calculation."
            result=calculate_reimbursement(numbers[0],numbers[1])
            audit(user_id,role,"calculate","calculate_reimbursement","success")
            return f"Calculated estimate: {result}. This is an estimate, not an approval."

    topic=None
    for key in POLICY:
        if key in lower:
            topic=key
            break

    if topic:
        if not authorized(role,"search_expense_policy"):
            audit(user_id,role,"policy_search","search_expense_policy","denied")
            return "Your role is not authorized to search this policy."

        result=search_expense_policy(topic)
        audit(user_id,role,"policy_search","search_expense_policy","success")
        return result[topic]

    audit(user_id,role,"unknown_request","none","escalated")
    return "I do not have enough approved policy information to answer that request. Please contact the appropriate human reviewer."

def main():
    user=input("User ID: ").strip()
    role=input("Role (EMPLOYEE/MANAGER/AUDITOR): ").strip()
    request=input("Request: ").strip()

    if not user or role not in ROLES or not request:
        print("Invalid input or role.")
        return

    print("\nAGENT RESPONSE")
    print(run_agent(user,role,request))

if __name__=="__main__":
    main()
