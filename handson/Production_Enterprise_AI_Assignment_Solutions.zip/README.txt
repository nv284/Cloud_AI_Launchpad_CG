Two class assignments are included.

1. Production-Grade AI Applications
   Reference: production_ai_api_solution.py
   Requires FastAPI/Uvicorn for the REST API.

2. Enterprise Agentic Systems, Governance, Security & Responsible AI
   Reference: governed_enterprise_agent_solution.py
   Uses Python standard library.

The solutions are classroom reference implementations. They use mock/local AI behavior and do not require real model credentials.

Never place secrets or real employee/customer data in source code or logs.
