"""
Production-Grade AI API - Reference Solution
Run with: pip install fastapi uvicorn
Then: uvicorn production_ai_api:app --reload
"""

import os
import time
import uuid
import logging
from collections import defaultdict, deque
from datetime import datetime, timezone
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

logging.basicConfig(level=os.getenv("LOG_LEVEL","INFO"))
logger=logging.getLogger("production-ai-api")

app=FastAPI(title="Production AI Support API")

MAX_REQUESTS=int(os.getenv("MAX_REQUESTS_PER_MINUTE","10"))
AI_MODEL=os.getenv("AI_MODEL","mock-model")

request_times=defaultdict(deque)

class AskRequest(BaseModel):
    user_id: str = Field(min_length=1, max_length=100)
    question: str = Field(min_length=1, max_length=2000)

def now():
    return datetime.now(timezone.utc).isoformat()

def generate_ai_response(question: str):
    q=question.lower()
    if "password" in q:
        return "Use the approved enterprise password-reset process."
    if "vpn" in q:
        return "Check your network connection and use the approved VPN client."
    return "The mock AI service received the request. Consult the approved knowledge source."

def check_rate_limit(user_id):
    current=time.time()
    window_start=current-60
    events=request_times[user_id]

    while events and events[0] < window_start:
        events.popleft()

    if len(events) >= MAX_REQUESTS:
        return False

    events.append(current)
    return True

@app.middleware("http")
async def correlation_logging(request: Request, call_next):
    request_id=str(uuid.uuid4())
    start=time.perf_counter()
    response=await call_next(request)
    elapsed=round((time.perf_counter()-start)*1000,2)

    response.headers["X-Request-ID"]=request_id
    logger.info({
        "timestamp":now(),
        "request_id":request_id,
        "endpoint":request.url.path,
        "status":response.status_code,
        "processing_ms":elapsed
    })
    return response

@app.exception_handler(Exception)
async def handle_exception(request: Request, exc: Exception):
    request_id=str(uuid.uuid4())
    logger.exception("Unhandled application error")
    return JSONResponse(
        status_code=500,
        content={
            "request_id":request_id,
            "status":"error",
            "error":"Internal application error",
            "timestamp":now()
        }
    )

@app.get("/health")
def health():
    return {"status":"healthy","timestamp":now()}

@app.get("/ready")
def ready():
    return {
        "status":"ready",
        "ai_model":AI_MODEL,
        "timestamp":now()
    }

@app.post("/ask")
def ask(payload: AskRequest):
    if not check_rate_limit(payload.user_id):
        return JSONResponse(
            status_code=429,
            content={
                "status":"rate_limited",
                "message":"Too many requests. Try again later.",
                "timestamp":now()
            }
        )

    request_id=str(uuid.uuid4())
    answer=generate_ai_response(payload.question)

    return {
        "request_id":request_id,
        "status":"success",
        "answer":answer,
        "timestamp":now()
    }
